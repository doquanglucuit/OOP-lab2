#include"Diem.h"
using ld = long double;
class Polygon {
private:
    int n;
    Diem *Dinh;
public:
    Polygon () {}
    Polygon (int _n, Diem *_Dinh): n(_n), Dinh(_Dinh) {}
    void Nhap ();
    ld Area ();
};
