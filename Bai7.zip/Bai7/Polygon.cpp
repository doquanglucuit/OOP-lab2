#include<bits/stdc++.h>
#include"Polygon.h"
using namespace std;
using ld = long double;
void Polygon::Nhap () {
    cin >> this->n;
    this->Dinh = new Diem[this->n];
    for (int i = 0; i < n; i++)
        Dinh[i].Nhap();
}

ld Polygon::Area () {
    ld res = 0;
    for (int i = 0; i < this->n; i++) {
        res = res + this->Dinh[i].CROSS(this->Dinh[(i + 1) % this->n]);
    }
    res = 0.5 * res;
    if (res < 0) res = -res;
    return res;
}
