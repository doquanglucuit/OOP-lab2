#include <bits/stdc++.h>

using namespace std;
#include"Polygon.h"
int main() {
    Polygon P;
    P.Nhap();
    cout << P.Area();
    return 0;
}
