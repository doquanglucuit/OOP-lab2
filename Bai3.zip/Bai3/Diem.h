using ld = long double;
class Diem {
private:
    ld x, y;
public:
    Diem () {}
    Diem (ld _x, ld _y): x(_x), y(_y) {}
    Diem (const Diem &oth);
    void Nhap ();
    void Xuat ();
    ld GetHoanhDo ();
    ld GetTungDo ();
    void SetHoanhDo (const ld &x);
    void SetTungDo (const ld &y);
    void TinhTien (ld x = 0, ld y = 0);
    Diem operator + (const Diem &oth) const;
    Diem operator - (const Diem &oth) const;
    Diem operator * (ld k) const;
    Diem Quay (ld alpha) const;
};

