#include <bits/stdc++.h>
#include"Polygon.h"
using namespace std;

int main()  {
    Polygon P;
    ld x, y, k, alpha;
    P.Nhap();
    P.Xuat(); cout << endl;
    cout << "Nhap vector tinh tien da giac: ";
    cin >> x >> y;
    P.TinhTien(x, y);
    cout << "Sau khi tinh tien da giac theo vector (" << x << ", " << y << "): "; P.Xuat(); cout << endl;
    cout << "Nhap he so phong to da giac: ";
    cin >> k;
    if (k == 0) {
        cout << "Khong the phong to da giac voi he so k = " << 0 << endl;
    }
    else {
        P.PhongTo(k);
        cout << "Sau khi phong to voi he so k = " << k << ": "; P.Xuat(); cout << endl;
    }

    cout << "Nhap he so thu nho da giac: ";
    cin >> k;
    if (k == 0) {
        cout << "Khong the thu nho  da giac voi he so k = " << 0 << endl;
    }
    else {
        P.ThuNho(k);
        cout << "Sau khi thu nho voi he so k = " << k << ": "; P.Xuat(); cout << endl;
    }

    cout << "Nhap goc muon xoay da giac: "; cin >> alpha;
    P.Quay(alpha);
    cout << "Sau khi quay da giac 1 goc alpha = " << alpha << ": "; P.Xuat(); cout << endl;
}
