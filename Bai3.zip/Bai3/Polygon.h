#include"Diem.h"
using ld = long double;
class Polygon {
private:
    int n;
    Diem *Dinh;
public:
    Polygon () {}
    Polygon (int _n, Diem *_Dinh): n(_n), Dinh(_Dinh) {}
    void Nhap ();
    void Xuat ();
    void TinhTien (ld x = 0, ld y = 0);
    void PhongTo (ld k = 1);
    void ThuNho (ld k = 1);
    void Quay (ld alpha = 0);
};
