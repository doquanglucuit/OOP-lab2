#include<bits/stdc++.h>
#include"Polygon.h"
using namespace std;

void Polygon::Nhap () {
    cout << "Nhap so dinh cua da giac: "; cin >> this->n;
    cout << "Nhap cac dinh cua da giac: ";
    this->Dinh = new Diem[this->n];
    for (int i = 0; i < n; i++)
        Dinh[i].Nhap();
}

void Polygon::Xuat () {
    for (int i = 0; i < this->n; i++) {
        cout << "("; Dinh[i].Xuat(); cout << ")";
        if (i < n - 1) cout << ", ";
    }
}

void Polygon::TinhTien (ld _x, ld _y) {
    for (int i = 0; i < this->n; i++)
        this->Dinh[i].TinhTien(_x, _y);
}

void Polygon::PhongTo (ld k) {
    for (int i = 1; i < this->n; i++) {
        Diem AI = Dinh[i] - Dinh[0];
        AI = AI * k;
        this->Dinh[i] = AI + Dinh[0];
    }
}

void Polygon::ThuNho (ld k) {
    this->PhongTo(1.0 / k);
}

void Polygon::Quay (ld alpha) {
    for (int i = 0; i < this->n; i++)
        this->Dinh[i] = this->Dinh[i].Quay(alpha);
}
