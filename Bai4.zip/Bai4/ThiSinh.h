#include<bits/stdc++.h>

using ld = long double;
using namespace std;
class ThiSinh {
private:
    string Ten;
    int MSSV, iNgay, iThang, iNam;
    ld fToan, fVan, fAnh;
public:
    ThiSinh () {}
    ThiSinh (string _Ten, int _MSSV, int _iNgay, int _iThang, int _iNam, ld _fToan,  ld _fVan, ld _fAnh):
        Ten(_Ten), MSSV(_MSSV), iNgay(_iNgay), iThang(_iThang), iNam(_iNam), fToan(_fToan), fVan(_fVan), fAnh(_fAnh) {}

    void Nhap ();
    void Xuat();
    ld Tong ();
};
