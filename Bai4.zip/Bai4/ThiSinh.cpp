#include<bits/stdc++.h>
#include"ThiSinh.h"

using namespace std;

void ThiSinh::Nhap () {
    cin.ignore();
    cout << "Nhap ten hoc sinh: "; getline(cin, this->Ten);
    cout << "Nhap MSSV: "; cin >> this->MSSV;
    cout << "Nhap ngay thang nam sinh: "; cin >> this->iNgay >> this->iThang >> this-> iNam;
    cout << "Nhap diem toan: "; cin >> this->fToan;
    cout << "Nhap diem van: "; cin >> this->fVan;
    cout << "Nhap diem tieng anh: "; cin >> this->fAnh;

}

void ThiSinh::Xuat () {
    cout << "Ten hoc sinh: " << this->Ten << endl;
    cout << "MSSV: " << this->MSSV << endl;
    cout << "Ngay/Thang/Nam sinh: " << this->iNgay << "/" << this->iThang << "/" << this->iNam << endl;
    cout << fixed << setprecision(2) << "Diem toan: " << fToan << ", Diem van: " << fVan << ", Diem tieng anh: " << fAnh << endl;
    cout << fixed << setprecision(2) << "Diem tong: " << this->Tong() << endl;
}

ld ThiSinh::Tong () {
    return this->fToan + this->fVan + this->fAnh;
}
