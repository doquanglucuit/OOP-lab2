#include <bits/stdc++.h>

using namespace std;
#include"ThiSinh.h"

int main() {
    int n, maxIndex = 0;
    ThiSinh *DSThiSinh;

    cout << "Nhap so thi sinh: "; cin >> n;
    DSThiSinh = new ThiSinh[n];

    for (int i = 0; i < n; i++) {
        cout << "Nhap thong tin cho hoc sinh " << i + 1 << endl;
        DSThiSinh[i].Nhap();
    }

    cout << "Thong tin cac thi sinh co tong diem >= 15: " << endl;
    for (int i = 0; i < n; i++) {
        if (DSThiSinh[i].Tong() >= 15.0) {
            DSThiSinh[i].Xuat(); cout << endl;
        }

        if (DSThiSinh[i].Tong() > DSThiSinh[maxIndex].Tong())
            maxIndex = i;
    }

    cout << "Thi sinh co diem cao nhat: " << endl;
    DSThiSinh[maxIndex].Xuat();
}
