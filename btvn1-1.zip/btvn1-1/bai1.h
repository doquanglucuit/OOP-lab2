#include<bits/stdc++.h>
using namespace std;

class Fraction{
private:
    int tuso;
    int mauso;

public:
    Fraction () {}
    Fraction(int tu, int mau) : tuso(tu), mauso(mau) {}

    int LayTu() const;
    int LayMau() const;

    Fraction(const Fraction &p) {
        this->tuso = p.LayTu();
        this->mauso = p.LayMau();
    }

    void GanTu(int t);

    void GanMau(int m);

    void Nhap();

    void Xuat();

    bool operator > (const Fraction ps) const;
    bool operator < (const Fraction ps) const;
    Fraction operator +  (const Fraction ps) const;

    Fraction operator - (const Fraction ps) const;

};

class arrFraction {
private:
    vector<Fraction> arr;

public:
    void nhap(int n);

    void xuat();

    Fraction LayPS(int i);

    Fraction LayPSLonNhat();

    Fraction LayPSNhoNhat();
};
