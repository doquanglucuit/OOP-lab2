#include<bits/stdc++.h>
using namespace std;

class Fraction {
public:
    long long tu, mau;

    Fraction(long long tu = 0, long long mau = 1) : tu(tu), mau(mau) {}

    void rutGon();

    Fraction operator*(const Fraction& oth) const;

    bool operator<(const Fraction& oth) const;

    bool operator>(const Fraction& oth) const;

    bool operator==(const Fraction& oth) const;
};

void timTapCon(vector<Fraction> arr, Fraction FractionDich);
