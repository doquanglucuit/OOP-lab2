#include<bits/stdc++.h>
#include "bai3.h"
using namespace std;

void Fraction::rutGon() {
    long long gcd_val = __gcd(tu, mau);
    tu /= gcd_val;
    mau /= gcd_val;
    if (mau < 0) {
        tu = -tu;
        mau = -mau;
    }
}

Fraction Fraction::operator*(const Fraction& other) const {
    return Fraction(tu * other.tu, mau * other.mau);
}

bool Fraction::operator<(const Fraction& other) const {
    return tu * other.mau < mau * other.tu;
}

bool Fraction::operator>(const Fraction& other) const {
    return tu * other.mau > mau * other.tu;
}

bool Fraction::operator==(const Fraction& other) const {
    return tu * other.mau == mau * other.tu;
}

void timTapCon(vector<Fraction> arr, Fraction dich) {
    bool found = false; //tim thay hay chua
    int n = arr.size();
    vector<Fraction> ans;

// lay 2^n truong hop cua tap con
    for (int mask = 1; mask < (1 << n); ++mask) {
        vector<Fraction> tapcon;
        Fraction tich(1, 1);

//lay tung phan so theo mask
        for (int i = 0; i < n; ++i) {
            if (mask & (1 << i)) {
                tapcon.push_back(arr[i]);
                tich = tich * arr[i];
                tich.rutGon();
            }
        }

        if (tich == dich) {
            found = true;
            if (ans.empty() || tapcon.size() < ans.size()) {
                ans = tapcon;
            }
        }
    }

    if (!found) {
        cout << "Ko co tap con nao thoa man" << endl;
    } else {
        sort(ans.begin(), ans.end());
        cout << "Tap hop con nho nhat co tich bang phan so dich: " << endl;
        for (auto ps : ans) {
            cout << ps.tu << "/" << ps.mau << " ";
        }
        cout << endl;
    }
}
