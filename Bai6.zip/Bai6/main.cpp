#include <bits/stdc++.h>
#include"TamGiac.h"

using namespace std;
using ld = long double;
const ld PI = 3.14;

int main() {
    TamGiac R;
    R.Nhap();
    ld alpha, length; cin >> alpha >> length;
    Diem X(length, 0);
    X = X.Quay(PI * alpha / 180);

    R.TinhTien(X.GetHoanhDo(), X.GetTungDo());
    R.Xuat();
    return 0;
}
