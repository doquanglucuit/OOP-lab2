#include"Diem.h"

class TamGiac {
private:
    Diem A, B, C;
public:
    TamGiac () {}
    TamGiac (Diem _A, Diem _B, Diem _C): A(_A), B(_B), C(_C) {}
    void Nhap ();
    void Xuat ();
    void TinhTien (ld x = 0, ld y = 0);
    void PhongTo (ld k = 1);
    void ThuNho (ld k = 1);
    void Quay (ld alpha= 0); // Quay tam giac theo goc toa do 1 goc alpha
};

