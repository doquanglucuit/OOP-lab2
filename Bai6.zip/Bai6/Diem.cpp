#include<bits/stdc++.h>

using namespace std;
using ld = long double;
#include"diem.h"

void Diem::Nhap () {
    cin >> this->x >> this->y;
}

void Diem::Xuat () {
    cout << fixed << setprecision(5) << this->x << ", " << this->y;
}

Diem::Diem(const Diem &oth) {
    this->x = oth.x;
    this->y = oth.y;
}

ld Diem::GetHoanhDo () { return this->x; }
ld Diem::GetTungDo  () { return this->y; }

void Diem::SetHoanhDo (const ld &x) {
    this->x = x;
}

void Diem::SetTungDo (const ld &y) {
    this->y = y;
}

void Diem::TinhTien (ld x, ld y) {
    this->x += x;
    this->y += y;
}

Diem Diem::operator + (const Diem &oth) const { return Diem(this->x + oth.x, this->y + oth.y); }
Diem Diem::operator - (const Diem &oth) const { return Diem(this->x - oth.x, this->y - oth.y); }
Diem Diem::operator * (ld k) const { return Diem(this->x * k, this->y * k); }

Diem Diem::Quay (ld alpha) const {
    ld x = this->x * cos(alpha) - this->y * sin(alpha);
    ld y = this->x * sin(alpha) + this->y * cos(alpha);
    return Diem(x, y);
}

