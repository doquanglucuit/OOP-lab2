#include <bits/stdc++.h>
#include"Diem.h"
using namespace std;

int main() {
    Diem A;
    int n;
    A.Nhap();
    cin >> n;
    for (int i = 1; i <= n; i++) {
        int x; cin >> x;
        A.Query(x);
    }
    A.Xuat();
}
