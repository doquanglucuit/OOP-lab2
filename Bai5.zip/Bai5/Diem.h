class Diem {
private:
    float x, y;
public:
    Diem () {}
    Diem (float _x, float _y): x(_x), y(_y) {}

    void Nhap ();
    void Xuat ();
    void Query (int x);
};
