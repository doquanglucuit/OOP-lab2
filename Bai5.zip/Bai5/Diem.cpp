#include<bits/stdc++.h>
#include"Diem.h"
using namespace std;

int dx[] = {1, 0};
int dy[] = {0, 1};

void Diem::Nhap () {
    cin >> this->x >> this->y;
}

void Diem::Xuat () {
    cout << this->x << ' ' << this->y;
}

void Diem::Query (int x) {
    if (x == 1) {
        this->x = this->x * 2;
        this->y = this->y * 2;
    }
    if (x == 2) {
        this->x = this->y = 0;
    }
    if (x == 3) {
        float k, d; cin >> k >> d;
        bool dir = k != 0;
        this->x += dx[dir] * d;
        this->y += dy[dir] * d;
    }
}
