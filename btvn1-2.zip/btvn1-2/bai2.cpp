#include<bits/stdc++.h>
#include "bai2.h"
using namespace std;

int Fraction::LayTu() const { return this->tuso;}

int Fraction::LayMau() const {  return this->mauso; }

void Fraction::GanTu(int t) { this->tuso = t; }

void Fraction::GanMau(int m) { this->mauso = m; }

void Fraction::Nhap() {
    cout << "Nhap tu so: ";
    cin >> this->tuso;
    cout << "Nhap mau so: ";
    cin >> this->mauso;
    while (this->mauso == 0) {
        cout << "Mau khong the bang 0, nhap lai mau so: ";
        cin >> this->mauso;
    }
}

void Fraction::Xuat() {
    cout << tuso << "/" << mauso << endl;
}
bool Fraction::operator>(const Fraction ps) const {
    return 1.0 * tuso / mauso > 1.0 * ps.LayTu() / ps.LayMau();
}

bool Fraction::operator<(const Fraction ps) const {
    return 1.0 * tuso  / mauso < 1.0 * ps.LayTu() / 1.0 * ps.LayMau();
}
Fraction Fraction::operator + (const Fraction ps) const {
    return Fraction(tuso * ps.LayMau() + mauso * ps.LayTu(), mauso * ps.LayMau());
}
Fraction Fraction::operator - (const Fraction ps) const {
    return Fraction(tuso * ps.LayMau() - mauso * ps.LayTu(), mauso * ps.LayMau());
}

void arrFraction::nhap(int n) {
    arr.clear();
    int tu, mau;
    for (int i = 0; i < n; ++i) {
        cout << "Nhap tu so cua ps thu " << i + 1 << ": ";
        cin >> tu;
        cout << "Nhap mau so cua ps thu " << i + 1 << ": ";
        cin >> mau;
        while (mau == 0) {
            cout << "Mau khong the bang 0, hay nhap lai: ";
            cin >> mau;
        }
        arr.push_back(Fraction(tu, mau));
    }
}

void arrFraction::xuat() {
    for (Fraction ps : arr) {
        ps.Xuat();
        cout << " ";
    }
    cout << endl;
}

Fraction arrFraction::LayPS(int i) {
    return arr[i];
}

Fraction arrFraction::LayPSLonThu(int k) {
    sort(arr.begin(), arr.end());
    if (k > arr.size()) {
        cout << "Khong co phan so lon thu " << k << endl;
    } else {
        cout << "Phan so lon thu " << k << " la ";
        arr[arr.size() - k].Xuat();
    }
    return arr[arr.size() - k];
}

Fraction arrFraction::LayPSNhoThu(int k) {
    sort(arr.begin(), arr.end());
    if (k > arr.size()) {
        cout << "Khong co phan so nho thu " << k << endl;
    } else {
        cout << "Phan so nho thu " << k << " la ";
        arr[k-1].Xuat();
    }
    return arr[k];
}
