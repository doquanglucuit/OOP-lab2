#include<bits/stdc++.h>
#include"diem.h"

using namespace std;


using lli = long long int;


int main() {
    Diem a;
    a = Diem(4, 5);
    cout << "a: "; a.Xuat();
    Diem b(a);
    cout << "b: "; b.Xuat();

    cout << "Hoanh do cua a: " << a.GetHoanhDo() << endl;
    cout << "Tung do cua b: " << b.GetTungDo() << endl;

    a.SetHoanhDo(6);
    a.SetTungDo(9);
    cout << "Sau khi update a: "; a.Xuat();

    b.TinhTien();
    cout << "Sau khi tinh tien b: "; b.Xuat();
}
