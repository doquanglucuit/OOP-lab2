#include<bits/stdc++.h>
using namespace std;

#include"diem.h"

void Diem::Xuat () {
    cout << this->x << ' ' << this->y << endl;
}

Diem::Diem(const Diem &oth) {
    this->x = oth.x;
    this->y = oth.y;
}

int Diem::GetHoanhDo () { return this->x; }
int Diem::GetTungDo  () { return this->y; }

void Diem::SetHoanhDo (const int &x) {
    this->x = x;
}

void Diem::SetTungDo (const int &y) {
    this->y = y;
}

void Diem::TinhTien (int _x, int _y) {
    this->x += _x;
    this->y += _y;
}
