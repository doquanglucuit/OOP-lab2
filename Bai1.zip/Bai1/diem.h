class Diem {
private:
    int x, y;
public:
    Diem () {}
    Diem (int _x, int _y): x(_x), y(_y) {}
    Diem (const Diem &oth);
    void Xuat ();
    int GetHoanhDo ();
    int GetTungDo ();
    void SetHoanhDo (const int &x);
    void SetTungDo (const int &y);
    void TinhTien (int x = 0, int y = 0);
};
