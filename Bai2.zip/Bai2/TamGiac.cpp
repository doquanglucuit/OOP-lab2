#include<bits/stdc++.h>
#include"TamGiac.h"
using namespace std;
using ld = long double;
void TamGiac::Nhap () {
    this->A.Nhap();
    this->B.Nhap();
    this->C.Nhap();
}

void TamGiac::Xuat () {
    cout << "(";
    A.Xuat(); cout << "), (";
    B.Xuat(); cout << "), (";
    C.Xuat(); cout << ")";
}

void TamGiac:: TinhTien (ld _x, ld _y) {
    this->A.TinhTien(_x, _y);
    this->B.TinhTien(_x, _y);
    this->C.TinhTien(_x, _y);
}

void TamGiac::PhongTo (ld k) {
    Diem AB = this->B - this->A;
    Diem AC = this->C - this->A;
    AB = AB * k;
    AC = AC * k;
    this->B = AB + this->A;
    this->C = AC + this->A;
}

void TamGiac::ThuNho (ld k) {
    this->PhongTo(1.0 / k);
}

void TamGiac::Quay (ld alpha) {
    this->A = this->A.Quay(alpha);
    this->B = this->B.Quay(alpha);
    this->C = this->C.Quay(alpha);
}
