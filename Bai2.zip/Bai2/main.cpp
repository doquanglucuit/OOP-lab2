#include <bits/stdc++.h>

using namespace std;
#include"TamGiac.h"

int main() {
    TamGiac S;
    ld x, y, k, alpha;

    cout << "Nhap toa do 3 dinh cua tam giac: ";
    S.Nhap();

    cout << "In tam giac: "; S.Xuat(); cout << endl;

    cout << "Nhap vector tinh tien: "; cin >> x >> y;
    S.TinhTien(x, y);
    cout << "Tinh tien tam giac theo vector (" << x << ", " << y << "): "; S.Xuat(); cout << endl;

    cout << "Nhap he so muon phong to: "; cin >> k;
    if (k == 0) cout << "Khong the phong to voi he so k = 0";
    else {
        S.PhongTo(k);
        cout << "Sau khi phong to voi he so k = " << k << ": "; S.Xuat(); cout << endl;
    }

    cout << "Nhap he so muon thu nho: "; cin >> k;
    if (k == 0) cout << "Khong the thu nho voi he so k = 0";
    else {
        S.ThuNho(k);
        cout << "Sau khi thu nho voi he so k = " << k << ": "; S.Xuat(); cout << endl;
    }

    cout << "Nhap goc muon quay (radian): "; cin >> alpha;
    S.Quay(alpha);
    cout << "Sau khi quay 1 goc " << alpha << ": "; S.Xuat();
}
